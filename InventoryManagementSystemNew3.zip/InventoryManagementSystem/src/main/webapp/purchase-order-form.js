//
//
// function roundNumber(number,decimals) {
//     var newString;// The new rounded number
//     decimals = Number(decimals);
//     if (decimals < 1) {
//         newString = (Math.round(number)).toString();
//     } else {
//         var numString = number.toString();
//         if (numString.lastIndexOf(".") == -1) {// If there is no decimal point
//             numString += ".";// give it one at the end
//         }
//         var cutoff = numString.lastIndexOf(".") + decimals;// The point at which to truncate the number
//         var d1 = Number(numString.substring(cutoff,cutoff+1));// The value of the last decimal place that we'll end up with
//         var d2 = Number(numString.substring(cutoff+1,cutoff+2));// The next decimal, after the last one we want
//         if (d2 >= 5) {// Do we need to round up at all? If not, the string will just be truncated
//             if (d1 == 9 && cutoff > 0) {// If the last digit is 9, find a new cutoff point
//                 while (cutoff > 0 && (d1 == 9 || isNaN(d1))) {
//                     if (d1 != ".") {
//                         cutoff -= 1;
//                         d1 = Number(numString.substring(cutoff,cutoff+1));
//                     } else {
//                         cutoff -= 1;
//                     }
//                 }
//             }
//             d1 += 1;
//         }
//         if (d1 == 10) {
//             numString = numString.substring(0, numString.lastIndexOf("."));
//             var roundedNum = Number(numString) + 1;
//             newString = roundedNum.toString() + '.';
//         } else {
//             newString = numString.substring(0,cutoff) + d1.toString();
//         }
//     }
//     if (newString.lastIndexOf(".") == -1) {// Do this again, to the new string
//         newString += ".";
//     }
//     var decs = (newString.substring(newString.lastIndexOf(".")+1)).length;
//     for(var i=0;i<decimals-decs;i++) newString += "0";
//     //var newNumber = Number(newString);// make it a number if you like
//     return newString; // Output the result to the form field (change for your purposes)
// }

function update_total() {
    var total = 0;
    $('.price').each(function(i){
        price = $(this).html().replace("","");
        if (!isNaN(price)) total += Number(price);
    });

    // total = roundNumber(total,2);
    $('#subtotal').html(total);

    // var cgst = document.getElementById("cgst_value").value;
    var subtotal = document.getElementById("subtotal").innerHTML;
    // var cgst_per = Math.round((Number(subtotal) * cgst)/100);
    // document.getElementById("cgst").innerHTML = cgst_per;
    // var sgst = document.getElementById("sgst_value").value;
    //
    // var sgst_per = Math.round((Number(subtotal) * sgst)/100);
    // document.getElementById("sgst").innerHTML = sgst_per;
    //
    // var igst = document.getElementById("igst_value").value;
    // var igst_per = Math.round((Number(subtotal) * igst)/100);
    // document.getElementById("igst").innerHTML = igst_per;
    //

    var packingcharges = document.getElementById("packingchargesvalue").value;
    var compensationcess = document.getElementById("compensationcessvalue").value;
    var tcs = document.getElementById("tcsvalue").value;

    var packingchargevalue = Math.round((Number(subtotal)*Number(packingcharges))/100);
    document.getElementById("packingcharges").innerHTML = packingchargevalue;

    var compensationcessvalue = Math.round((Number(subtotal) * Number(compensationcess))/100);
    document.getElementById("compensationcess").innerHTML = compensationcessvalue;

    var tcsvalue = Math.round((Number(subtotal) * Number(tcs))/100);
    document.getElementById("tcs").innerHTML = tcsvalue;

    var total = Number(packingchargevalue)+Number(compensationcessvalue)+Number(tcsvalue)+Number(subtotal);

     document.getElementById("total").innerHTML = total;

}



function update_price() {
    var row = $(this).parents('.item-row');
    var price = Number(row.find('.cost').val().replace("","")) * Number(row.find('.qty').val());
    // price = roundNumber(price,2);
    var totalgst = Number(row.find('.cgst').val().replace("","")) + Number(row.find('.sgst').val()) + Number(row.find('.igst').val());

    console.log(totalgst);
    price = Math.round((Number(price) * totalgst)/100);

    isNaN(price) ? row.find('.price').html("N/A") : row.find('.price').html(price);


    update_total();
}

function bind() {
    $(".cost").blur(update_price);
    $(".qty").blur(update_price);
    $(".cgst").blur(update_price);
    $(".sgst").blur(update_price);
    $(".igst").blur(update_price);
}

$(document).ready(function() {

    $('input').click(function(){
        $(this).select();
    });

    $("#addrow").click(function(){
        rowIndex;
        slno++;
        $(".item-row:last").after('<tr class="item-row"><td>'+slno+'</td><td class="item-name"><div class="delete-wpr"><input placeholder="Item Name And Description" type="text"><a class="delete" href="javascript:;" title="Remove row">X</a></div></td><td class="description"><input placeholder="HSN/SAC" type="text"></td><td><input class="qty" value="0" type="number" oninput="if(this.value < 0) this.value=0"></td><td><input class="cost" type="number" value="0" oninput="if(this.value < 0) this.value=0"></td><td><input type="number" class="cgst" id="cgstvalue'+rowIndex+'" value="0" oninput="if((this.value) > 100) this.value=100; else if((this.value)<0) this.value=1" ></td><td><input type="number" class="sgst" id="sgstvalue'+rowIndex+'" value="0" oninput="if((this.value) > 100) this.value=100; else if((this.value)<0) this.value=1"></td><td><input type="number" class="igst" id="igstvalue'+rowIndex+'" value="0" oninput="if((this.value) > 100) this.value=100; else if((this.value)<0) this.value=1"></td><td><span class="price">0</span></td></tr>');
        if ($(".delete").length > 0) $(".delete").show();
        bind();
    });

    bind();

    $(".delete").live('click',function(){
        $(this).parents('.item-row').remove();
        update_total();
        var tablebody  = document.getElementById("item-detail");
        var rows = tablebody.querySelectorAll("tr");
        for(var i=0;i<rows.length;i++){
            var col = rows[i].querySelector("td");
            slno = i;
            slno++;
            col.innerHTML = slno;

        }
        if ($(".delete").length < 0) $(".delete").hide();
    });

    $("#cancel-logo").click(function(){
        $("#logo").removeClass('edit');
    });
    $("#delete-logo").click(function(){
        $("#logo").remove();
    });
    $("#change-logo").click(function(){
        $("#logo").addClass('edit');
        $("#imageloc").val($("#image").attr('src'));
        $("#image").select();
    });
    $("#save-logo").click(function(){
        $("#image").attr('src',$("#imageloc").val());
        $("#logo").removeClass('edit');
    });


});