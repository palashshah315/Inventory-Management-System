package servlets.inventorymanagementsystem;

import DAO.*;
import BeanClass.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AddPurchaseOrderDetail", value = "/AddPurchaseOrderDetail")
public class AddPurchaseOrderDetail extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String purchaseOrderDetail = request.getParameter("purchaseorderdetails");
        String userid = request.getParameter("userid");
        String userfirstname = request.getParameter("userfirstname");
        String userlastname = request.getParameter("userlastname");
        String suppliername = request.getParameter("suppliername");
        String supplieremail = request.getParameter("supplieremail");
        String supplieraddress = request.getParameter("supplieraddress");
        String invoiceno = request.getParameter("invoiceno");
        String purchaseorderdate = request.getParameter("purchaseorderdate");
        String gstno = request.getParameter("gstno");
        String subtotal = request.getParameter("subtotal");
        String packigncharges = request.getParameter("packingcharge");
        String compensationcess = request.getParameter("compensationcess");
        String tcs = request.getParameter("tcs");
//        String cgst = request.getParameter("cgst");
//        String sgst = request.getParameter("sgst");
//        String igst = request.getParameter("igst");

        int status=0;

        SupplierBean sb = new SupplierBean();

        sb.setSuppliername(suppliername);
        sb.setSupplieremail(supplieremail);
        sb.setSupplieraddress(supplieraddress);
        sb.setPurchaseorderdate(purchaseorderdate);
        sb.setInvoiceno(invoiceno);
        sb.setGstno(gstno);
        sb.setSubtotal(subtotal);

        Dao d = new Dao();

        if(gstno.isEmpty() || gstno==null || purchaseorderdate.isEmpty() || purchaseorderdate==null || invoiceno.isEmpty() || invoiceno==null
        || supplieraddress.isEmpty() || supplieraddress==null || suppliername.isEmpty() || suppliername==null ||
        supplieremail.isEmpty() || supplieremail==null || userfirstname.isEmpty() || userfirstname==null || userlastname.isEmpty() || userlastname==null
        || userid.isEmpty() || userid==null || purchaseOrderDetail.isEmpty() || purchaseOrderDetail==null)
        {

            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Fields cannot be empty!!");

        }

        else{
            JSONParser parser = new JSONParser();
            try {
                JSONArray jsonarr = (JSONArray) parser.parse(purchaseOrderDetail);
                for (int i = 0; i < jsonarr.size(); i++)
                {
                    JSONObject jsonObj = (JSONObject) jsonarr.get(i);

                    status = d.addPurchaseOrder(userid,userfirstname,userlastname,sb,(String) jsonObj.get("productdetail"), (String) jsonObj.get("hsncode"), (String) jsonObj.get("quantity"), (String) jsonObj.get("unitcost"),(String) jsonObj.get("totalprice"),(String) jsonObj.get("cgst"),(String) jsonObj.get("sgst"),(String) jsonObj.get("igst"),packigncharges,compensationcess,tcs);

                }
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if(status > 0){
                response.setContentType("text/plain");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("Purchase bill detail added successfully");
            }
        }
    }
}
