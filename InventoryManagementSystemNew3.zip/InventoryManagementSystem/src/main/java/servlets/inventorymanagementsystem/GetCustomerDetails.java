package servlets.inventorymanagementsystem;

import BeanClass.OrderBean;
import DAO.Dao;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "GetCustomerDetails", value = "/GetCustomerDetails")
public class GetCustomerDetails extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customername = request.getParameter("customername");

        PrintWriter out = response.getWriter();
        if(customername.isEmpty() || customername == null){
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Customer name is empty ');");
            out.println("</script>");
        }
        else{
            Dao d = new Dao();

            List<OrderBean> list = d.getAllClientDetails(customername);

            JSONArray json = new JSONArray();
            for(OrderBean ob : list){
                JSONObject obj = new JSONObject();
                obj.put("clientemail", ob.getClientEmail());
                obj.put("clientaddress", ob.getClientAddress());
                obj.put("productname", ob.getProductname());
                json.add(obj);
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json.toString());

        }
    }
}
