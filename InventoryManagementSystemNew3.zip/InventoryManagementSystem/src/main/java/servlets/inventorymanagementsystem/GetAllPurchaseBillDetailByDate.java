package servlets.inventorymanagementsystem;

import BeanClass.SupplierBean;
import DAO.Dao;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.util.*;

@WebServlet(name = "GetAllPurchaseBillDetailByDate", value = "/GetAllPurchaseBillDetailByDate")
public class GetAllPurchaseBillDetailByDate extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fromdate = request.getParameter("fromdate");
        String todate = request.getParameter("todate");
        PrintWriter out = response.getWriter();
        JSONArray jsonArray = new JSONArray();

        if(fromdate.isEmpty() || fromdate == null || todate.isEmpty() || todate == null){
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Please give input of dates');");
            out.println("</script>");
        }

        else{
            Dao d = new Dao();
            List<SupplierBean> list = d.getAllSupplierDetailByDate(fromdate,todate);
            for (SupplierBean sb: list) {
                JSONObject obj = new JSONObject();
                obj.put("suppliername",sb.getSuppliername());
                obj.put("gstno",sb.getGstno());
                obj.put("invoiceno",sb.getInvoiceno());
                obj.put("hsn",sb.getHsncode());
                obj.put("purchaseorderdate",sb.getPurchaseorderdate());
                obj.put("subtotal",sb.getSubtotal());
                obj.put("quantity",sb.getQuantity());
                obj.put("cgst",sb.getCgst());
                obj.put("sgst",sb.getSgst());
                obj.put("igst",sb.getIgst());
                obj.put("packingcharges",sb.getPackingcharges());
                obj.put("compensationcess",sb.getCompensationcess());
                obj.put("tcs",sb.getTcs());
                jsonArray.add(obj);
            }
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonArray.toString());
        }
    }
}
